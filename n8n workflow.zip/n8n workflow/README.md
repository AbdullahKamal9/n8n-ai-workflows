# n8n AI Automation Agents

A collection of four production-ready AI automation agents built with n8n, Groq (LLaMA 3), and various APIs. Each agent automates a real business workflow end-to-end — no human in the loop for routine tasks.

---

## Table of Contents

1. [Client Intake Agent – Law Firm](#1-client-intake-agent--law-firm)
2. [Discord Community Manager Bot](#2-discord-community-manager-bot)
3. [E-Commerce Business Automation Agent](#3-e-commerce-business-automation-agent)
4. [Lead Generation & Scoring Agent](#4-lead-generation--scoring-agent)

---

## 1. Client Intake Agent – Law Firm

### Problem

Law firms waste hours on intake: manually reading case submissions, creating folders, logging case details, drafting response letters, and routing urgent cases to the right people. It's repetitive, error-prone, and slows down the firm's response time.

### What This Agent Does

A webhook receives a new client case submission. From there, the agent handles everything automatically:

- Generates a unique **Case ID** for tracking
- Sends the case details to **Groq AI** for analysis — extracting urgency, case type, and key facts
- Parses the AI response into structured data
- **Logs the case** to Google Sheets (append row)
- **Creates a dedicated Google Drive folder** for the case
- **Drafts a professional response letter** using Groq AI
- Checks urgency via an **IF node** — routes to two different email flows:
  - `NODE 9A` — Priority notification email to the company for urgent cases
  - `NODE 9B` — Standard notification email for regular cases
- Sends a **confirmation email to the client** (Node 10)

### Workflow Nodes

| Node | Function |
|------|----------|
| NODE 1 – Webhook Trigger | Receives case submission via HTTP POST |
| NODE 2 – Generate Case ID | Creates unique identifier for the case |
| NODE 3 – Groq AI Case Analysis | Analyzes case content, extracts urgency and type |
| NODE 4 – Parse Groq Response | Structures AI output for downstream nodes |
| NODE 5 – Google Sheets Append Row | Logs case to CRM sheet |
| NODE 6 – Google Drive Create Folder | Creates dedicated folder for case documents |
| NODE 7 – Groq AI Draft Response Letter | Generates professional client response |
| NODE 8 – IF Node Urgency Check | Routes based on urgency flag |
| NODE 9A – Gmail Priority Notification | Urgent case alert to company |
| NODE 9B – Gmail Standard Notification | Regular case notification to company |
| NODE 10 – Gmail Client Confirmation | Sends confirmation email to the client |

### Tech Stack

- **n8n** — workflow orchestration
- **Groq (LLaMA 3)** — case analysis and letter drafting
- **Google Sheets** — case logging and CRM
- **Google Drive** — folder creation per case
- **Gmail** — client and company email communication
- **Webhooks** — real-time trigger architecture

### Business Value

Replaces manual intake processing entirely. A firm receiving 20–50 submissions per week saves hours of admin work while improving response consistency and response time.

---

## 2. Discord Community Manager Bot

### Problem

Growing Discord servers hit a wall: spam floods channels faster than mods can respond, genuine questions go unanswered for hours, and admins have no visibility into what's actually happening without reading thousands of messages manually. Hiring moderators is expensive. Volunteer mods burn out.

### What This Agent Does

Every message in the server hits a webhook. The bot makes decisions automatically:

**Bot filter** — if the sender is a bot, the message is ignored. No wasted processing.

**For real users, Groq classifies the message into three paths simultaneously:**

- **Spam detected** → message deleted, user gets a warning DM, incident logged to Google Sheets
- **Needs admin attention** → admin receives a DM with full context, case logged separately for review
- **Normal message** → bot replies in-channel with an AI-generated response, logs the reply, confirms back to webhook

**Weekly summary** — a scheduled trigger pulls all logs from Sheets, sends them to Groq for pattern analysis, and posts a structured weekly report directly into Discord.

### What Makes This Different from a Basic Bot

Most Discord bots use keyword matching. This agent uses an LLM to understand context — it can tell the difference between spam and a legitimate resource share. It escalates intelligently instead of flagging everything. Every decision is also logged, so admins have full auditability.

### Tech Stack

- **n8n** — event-driven workflow orchestration
- **Groq (LLaMA 3)** — message classification, reply generation, weekly report summarization
- **Discord API** — message deletion, DMs, channel replies, report posting
- **Google Sheets** — persistent logging for spam, escalations, and replies
- **Webhooks** — real-time trigger architecture

### Business Value

Replaces the first 80% of moderation work for any community — SaaS product, creator brand, crypto project, or gaming server. Humans only handle edge cases. Weekly summaries give admins full visibility with zero effort.

---

## 3. E-Commerce Business Automation Agent

### Problem

Shopify store owners deal with the same three problems every week: replying to the same customer emails over and over, forgetting to follow up with high-value customers, and having no business visibility unless they pull reports manually. None of this requires a human.

### What This Agent Does

The agent runs on three separate trigger points:

**Trigger 1 — New Order (Webhook)**

Groq analyzes incoming customer data and routes:

- **VIP customer** → instant Slack alert + personalized welcome email → Day 3 follow-up → Day 7 loyalty email (all timed automatically)
- **Regular customer** → invoice email fires, record saved to Google Sheets CRM, webhook response sent

**Trigger 2 — Incoming Customer Email (Gmail Trigger)**

Groq reads the email, generates a contextual reply, and sends it. No human needed.

**Trigger 3 — Weekly Business Report (Scheduled)**

Reads the full CRM, aggregates data, sends it to Groq for analysis, and emails a business intelligence report to the owner.

### Tech Stack

- **n8n** — workflow orchestration
- **Groq (LLaMA 3)** — customer analysis, reply generation, report writing
- **Gmail** — customer communication
- **Google Sheets** — lightweight CRM
- **Slack** — real-time VIP alerts
- **Webhooks** — event-driven trigger architecture

### Business Value

For a solo store owner, this replaces hours of daily manual work. For a growing brand, it scales without adding headcount. This is not a chatbot — it's a system that thinks, routes, and acts across three trigger points with no human in the loop.

---

## 4. Lead Generation & Scoring Agent

### Problem

Most businesses handle leads manually: reading submissions, deciding which ones matter, writing individual outreach emails, and remembering to follow up days later. At any real volume, this breaks down. Hot leads go cold. Cold leads get ignored.

### What This Agent Does

The agent automates the full lead lifecycle from capture to follow-up:

- **Captures incoming leads** in real time via webhook
- **Groq AI analyzes** lead intent, budget, and message quality
- **Scores and classifies** each lead as HOT or COLD automatically

**HOT leads:**
- Instant Slack notification to the team
- AI-personalized outreach email sent immediately
- Automatic follow-up email triggered after 3 days (via wait node)

**COLD leads:**
- Automated nurturing email sequence

**All leads:**
- Logged automatically to Google Sheets CRM

### Tech Stack

- **n8n** — workflow orchestration
- **Groq (LLaMA 3.3 70B)** — lead analysis, scoring, personalized email generation
- **Gmail API** — outreach and follow-up emails
- **Slack API** — real-time HOT lead alerts
- **Google Sheets** — CRM and lead log
- **Webhooks** — real-time event-driven triggers

### Business Value

Eliminates manual lead triage entirely. Hot leads get contacted within minutes of submission. No leads fall through the cracks. The system scales without adding sales headcount.

---

## About

Built by **Abdullah Kamal** — AI Automation Engineer based in Karachi, Pakistan.

Specializing in AI agents and automation systems using n8n, Groq, LangChain, and Python.

Open to freelance projects and full-time AI automation roles.

- **LinkedIn:** https://www.linkedin.com/in/abdullah-kamal-854a59375/
- **Fiverr:** AI Automation & n8n Workflows
- **Email:** abdullahkamal165@gmail.com
